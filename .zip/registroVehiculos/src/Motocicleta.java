
public class Motocicleta extends Vehiculo{
    protected int cilindraje;
    protected String tipoManejo;
    
    public Motocicleta(String marca, String modelo, int año, double precioBase, int cilindraje, String tipoManejo) {
        super(marca, modelo, año, precioBase);
        this.cilindraje = cilindraje;
        this.tipoManejo = tipoManejo;
    }
    
    @Override
    public void mostrarInfo() {
        System.out.println("Modelo: " + modelo +", Marca: " + marca
                + ", Año: " + año + ", Salario: $" + calcularPrecio()
        + ", Cilindraje: "+ cilindraje + ", Tipo de manejo: " + tipoManejo);
    }
}
