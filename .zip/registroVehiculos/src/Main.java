import java.util.*;
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("------ Registrar Auto ------");
        
        System.out.print("Marca: ");
        String marcaAuto = scanner.nextLine();
        
        System.out.print("Modelo: ");
        String modeloAuto = scanner.nextLine();
        
        System.out.print("Año de fabricación: ");
        int añoAuto = scanner.nextInt();
        
        System.out.print("Precio base:");
        double prBsAuto= scanner.nextDouble();
        
        System.out.print("Número de puertas: ");
        int numPuerta = scanner.nextInt();
        scanner.nextLine();
        
        System.out.print("Tipo de combustible (Gasolina/Díesel/Electrico): ");
        String combustible = scanner.nextLine();
        
        Auto auto = new Auto(marcaAuto, modeloAuto, añoAuto, prBsAuto, numPuerta, combustible);
        
        System.out.println("------ Registrar Motocicleta ------");
        
        System.out.print("Marca: ");
        String marcaMoto = scanner.nextLine();
        
        System.out.print("Modelo: ");
        String modeloMoto = scanner.nextLine();
        
        System.out.print("Año de fabricación: ");
        int añoMoto = scanner.nextInt();
        
        System.out.print("Precio base: ");
        double prBsMoto = scanner.nextDouble();
        
        System.out.print("Cilindraje (cc): ");
        int cilindraje = scanner.nextInt();
        scanner.nextLine();
        
        System.out.print("Tipo de manejo (Deportiva/Crucero/Enduro): ");
        String manejo = scanner.nextLine();
        
        Motocicleta motocicleta = new Motocicleta(marcaMoto, modeloMoto, añoMoto, prBsMoto, cilindraje, manejo);
        
        System.out.println("------ Registrar Camioneta ------");
        
        System.out.print("Marca: ");
        String marcaCam = scanner.nextLine();
        
        System.out.print("Modelo: ");
        String modeloCam = scanner.nextLine();
        
        System.out.print("Año de fabricación: ");
        int añoCam = scanner.nextInt();
        
        System.out.print("Precio base: ");
        double prBsCam = scanner.nextDouble();
        
        System.out.print("Capacidad de carga (kg): ");
        double capacidad = scanner.nextDouble();
        scanner.nextLine();
        
        System.out.print("¿Tracción 4x4? (true/false): ");
        boolean traccion = scanner.nextBoolean();
        
        Camioneta camioneta = new Camioneta(marcaCam, modeloCam, añoCam, prBsCam, capacidad, traccion);
        
        System.out.println("\n=== REPORTE DE VEHICULOS ===");
        auto.mostrarInfo();
        motocicleta.mostrarInfo();
        camioneta.mostrarInfo();
        
        System.out.println("\n--- Polimorfismo ---");
        Vehiculo[] registro = {auto, motocicleta, camioneta};
        int count = 1;
        for (Vehiculo veh : registro) {
            System.out.print(count + ". ");
            veh.mostrarInfo();
            count++;
        }
    }
    
}
