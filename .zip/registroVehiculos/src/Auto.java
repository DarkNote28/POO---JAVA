
public class Auto extends Vehiculo{
    protected int nroPuertas;
    protected String combustible;
    
    public Auto(String marca, String modelo, int año, double precioBase, int nroPuertas, String combustible) {
        super(marca, modelo, año, precioBase);
        this.nroPuertas = nroPuertas;
        this.combustible = combustible;
    }
    @Override
    public void mostrarInfo() {
        System.out.println("Modelo: " + modelo +", Marca: " + marca
                + ", Año: " + año + ", Salario: $" + calcularPrecio()
        + ", Número de Puertas: "+ nroPuertas + ", Combustible: " + combustible);
    }
}
