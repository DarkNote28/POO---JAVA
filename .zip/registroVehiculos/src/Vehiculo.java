/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USUARIO
 */
public class Vehiculo {
    protected String marca;
    protected String modelo;
    protected int año;
    protected double precioBase;
    
    public Vehiculo(String marca, String modelo, int año, double precioBase) {
        this.modelo = modelo;
        this.marca = marca;
        this.año = año;
        this.precioBase = precioBase;
    }
    public double calcularPrecio() {
        return precioBase;
    }
    public void mostrarInfo() {
        System.out.println("Modelo: " + modelo +", Marca: " + marca+ ", Año: " + año + ", Salario: $" + calcularPrecio());
    }
}
