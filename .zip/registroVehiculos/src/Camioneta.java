public class Camioneta extends Vehiculo{
    protected double capacidadCarga;
    protected boolean traccion;
    
    public Camioneta(String marca, String modelo, int año, double precioBase, double capacidadCarga, boolean traccion) {
        super(marca, modelo, año, precioBase);
        this.capacidadCarga = capacidadCarga;
        this.traccion = traccion;
    }
    @Override
    public void mostrarInfo() {
        System.out.println("Modelo: " + modelo +", Marca: " + marca
                + ", Año: " + año + ", Salario: $" + calcularPrecio()
        + ", Número de Puertas: "+ capacidadCarga + ", Combustible: " + traccion);
    }
}
